%% Initial parameters

Ts = 0.02;   % sampling period
tf = 10;
t = 0:Ts:tf;
N = size(t,2);

jz = 0.0576; % inertia
m = 0.240;   % mass of the arm
d = 0.38;    % distance base-weight point
g = 9.81; 
L = 0.65;    % rod's length
fr = 0.1;    % friction

%% Dynamic model 

real_pos = zeros(1,N);
real_vel = zeros(1,N);
real_acc = zeros(1,N);

%Fh - the system's input 
w = 1; %rad/s
amp = 0.5; %amplitude
Fh = 0.5.*ones(1,N);%amp.*sin(w.*t) + amp;

%acc - dynamic eq° 
 for i=2:N
      real_acc(1,i) = 1/jz .* (Fh(1,i) .*L - d*m*g*sin(real_pos(i-1)) - fr*real_vel(1,i-1) ); % the friction is not considered in the Kalman filter
      real_vel(1,i) = real_vel(1,i-1) + real_acc(1,i) * Ts; 
      real_pos(1,i) = real_pos(1,i-1) + real_vel(1,i) * Ts;
 end

% Sensor data
oe_o = 0.02;
oe_do = 0.02;
noise_pos = real_pos + oe_o .* randn(1,N);
noise_vel = real_vel + oe_do .* randn(1,N);
noise_vel(1,200:300) = 0;

%% Extended Kalman Filter - First Order Polynomial
% The transition state matrix is updated at each loop. 
% The extrapolated estimation is therefore dependant on the current state. 

% The state vector is X = [theta, dtheta]'
% The transition state matrix is updated at each loop iteration

vars = {'P_0','X_est','X_proj','F','phi','Gd','Qk','Rk','Hk','pos_bound','vel_bound'};
clear(vars{:});

% Initial estimates
X_est = zeros(2,N);     % State vector (list of vectors)
X_proj = zeros(2,1);    % State projection vector
P_k = zeros(2);         % State error covariance matrix
P_proj = 10 .* [1 0; 0 1];   % Initial state error matrix
Kk = zeros(2,2);        % Kalman gain 

% Parameters 
Apf = 0;                % Functioning point variable
gamma = 0.1;

Vo = oe_o^2; %25*pi^2/180^2;      % [rad^2]
Vdo = oe_do^2; %0.05;             % Gyrometer variance [(rad/s)^2]

Gd = [ Ts^2 *L/(2*jz) ; Ts*L/jz]; % the input matrix 
G = [0 ; L/jz];
Rk = [Vo 0 ; 0 Vdo];    % Sensor noise covariance matrix
Qk = gamma .* eye(2);   % Process noise matrix
Hk = [1 0 ; 0 1];       % Measurement matrix

% Covariance boundaries
pos_bound = zeros(1,N);
vel_bound = zeros(1,N);


% Kalman Loop

for i=1:N
    Kk = P_proj * Hk' /(Hk * P_proj * Hk' + Rk);
    P_k = (eye(2) - Kk*Hk)*P_proj ; 

    X_est(:,i) = X_proj + Kk*( [noise_pos(1,i);noise_vel(1,i)] - Hk*X_proj);

    Apf = -d*m*g*cos(X_est(1,i))/jz;
    F = [0 1; Apf 0];
    phi = eye(2) + Ts.*F ;%+ 0.5.*(Ts.*F)^2;
    Qk = gamma.*[Ts+(Ts^3)/3 (Ts^2)*(Apf+1)/2 ; (Ts^2)*(Apf + 1)/2 (Ts^3)*(Apf^2)/3 + Ts];

    P_proj = phi * P_k * phi' + Qk;
    pos_bound(1,i) = sqrt(P_k(1,1));
    vel_bound(1,i) = sqrt(P_k(2,2));

    %X_proj = phi * X_est(:,i) + Gd * Fh(i);
    X_proj = X_est(:,i) + Ts.* (phi * X_est(:,i) + Gd * Fh(i)); %( F * X_est(:,i) + G * Fh(i))
end

%% Extended Kalman Filter - Second Order Polynomial

% The state vector is X = [theta, dtheta,ddtheta]'
% The transition state matrix is updated at each loop iteration
vars = {'P_0','X_est','X_proj','F','phi','Gd','Qk','Rk','Hk','pos_bound','vel_bound'};
clear(vars{:});

% Initial estimates
X_est = zeros(3,N);     % State vector (list of vectors)
X_proj = zeros(3,1);    % State projection vector
P_k = zeros(3);         % State error covariance matrix
P_proj = 10 .* [1 0 0; 0 1 0; 0 0 1];   % Initial state error matrix
Kk = zeros(3);        % Kalman gain 

% Parameters 
Apf = 0;               % Functioning point variable
Bpf = -fr /jz;         % Second functioning point variable
Cpf = 0;               % Third functioning point variable
gamma = 10;            % Noise spectral density

Vo = oe_o^2; %25*pi^2/180^2;      % [rad^2]
Vdo = oe_do^2; %0.05;             % Gyrometer variance [(rad/s)^2]

Gd = zeros(3,1) ;%[ Ts^2 *L/(2*jz) ; Ts*L/jz * (Bpf*Ts/2 + 1); 0]; % the input matrix 
G = [0 ; L/jz; 0];
Rk = [Vo 0; 0 Vdo];    % Sensor noise covariance matrix
Qk = gamma .* [1 0 0; 0 1 0; 0 0 1];   % Process noise matrix
Hk = [1 0 0; 0 1 0];       % Measurement matrix

% Covariance boundaries
pos_bound = zeros(1,N);
vel_bound = zeros(1,N);
acc_bound = zeros(1,N);

% Kalman Loop

for i=1:N
    Kk = P_proj * Hk' /(Hk * P_proj * Hk' + Rk);
    P_k = (eye(3) - Kk*Hk)*P_proj ; 

    X_est(:,i) = X_proj + Kk*( [noise_pos(1,i);noise_vel(1,i)] - Hk*X_proj);

    Apf = -d*m*g*cos(X_est(1,i))/jz;
    Cpf = Apf; %-d*m*g*cos(X_est(1,i))/jz; % Au final, c'est la meme chose que Apf

    F = [0 1 0; Apf Bpf 1; 0 Cpf Bpf];
    phi = eye(3) + Ts.*F ;%+ 0.5.*(Ts.*F)^2;

    % Discrete process noise computation
    q1_1 = Ts+(Ts^3)/3;
    q1_2 = 0.5*(1+Apf)*(Ts^2)+Bpf*(Ts^3)/3;
    q1_3 = Cpf*(Ts^3)/3;
    q2_1 = Apf*(Ts^3)/3;
    q2_2 = ((Ts^2)*Bpf)+Ts+((Apf^2)+(Bpf^2)+1)*(Ts^3)/3;
    q2_3 = Bpf*(Cpf+1)*((Ts^3)/3)+0.5*(Ts^2)*(Cpf+1);
    q3_1 = Cpf*(Ts^3)/3;
    q3_2 = (Cpf+1)*(Bpf*((Ts^3)/3)+(Ts^2)/2);
    q3_3 = ((Cpf^2)+(Bpf^2))*((Ts^3)/3)+(Ts^2)*Bpf+Ts;
    Qk = gamma .* [q1_1 q1_2 q1_3; q2_1 q2_2 q2_3 ; q3_1 q3_2 q3_3];

    Gd = [ (L*Ts^2)/(2*jz) ; L*(Ts + 0.5*Bpf*Ts^2)/jz ; 0.5*L*(Cpf*Ts^2)/jz ] ;

    % Qk = gamma.*[Ts + (Ts^3)/3  (Apf+Bpf)*(Ts^2)/2 + Ts 0 ;
    %     (Apf/2)*Ts^2 + (Bpf*Ts^3)/3 + (Ts^2)/2 Apf^2 * (Ts^3)/3 + Bpf^2 * (Ts^3)/3 + Bpf * (Ts^2) + Ts 0 ;
    %     0 0 0];

    P_proj = phi * P_k * phi' + Qk;

    % Admissible error boundaries
    pos_bound(1,i) = sqrt(P_k(1,1));
    vel_bound(1,i) = sqrt(P_k(2,2));
    acc_bound(1,i) = sqrt(P_k(3,3));

    X_proj = X_est(:,i) + Ts.* (phi * X_est(:,i) + Gd * Fh(i)); %( F * X_est(:,i) + G * Fh(i));
end
%% Plots

% Real motion vs. noised data
figure(1);
subplot(3,1,1);
plot(t,real_pos,'--',t,noise_pos);
title("Real position [rad]");
xlabel("Time [s]");
ylabel("Position [rad]");

subplot(3,1,2);
plot(t,real_vel,'--',t,noise_vel);
title("Real velocity [rad/s]");
xlabel("Time [s]");
ylabel("Velocity [rad/s]");

subplot(3,1,3);
plot(t,real_acc);
title("Real acceleration [rad/s^2]");
xlabel("Time [s]");
ylabel("Acceleration [rad/s^2]");

%% Kalman filter estimation
figure(2);
subplot(2,2,1);
plot(t,real_pos,'--',t,X_est(1,:));
title("Comparaison between real Vs. estimated position [rad]");
xlabel("Time [s]");
ylabel("Position [rad]");

subplot(2,2,2);
err_pos = real_pos-X_est(1,:);
plot(t,err_pos,'.',t,pos_bound,'--',t,-pos_bound,'--');
title("Position estimation error [rad]");
xlabel("Time [s]");
ylabel("Position [rad]");

subplot(2,2,3);
plot(t,real_vel,'--',t,X_est(2,:));
title("Comparaison between real Vs. estimated velocity [rad/s]");
xlabel("Time [s]");
ylabel("Angular velocity [rad/s]");

subplot(2,2,4);
err_vel = real_vel-X_est(2,:);
plot(t,err_vel,'.',t,vel_bound,'--',t,-vel_bound,'--');
title("Velocity estimation error [rad/s]");
xlabel("Time [s]");
ylabel("Angular velocity [rad/s]");

%% Kalman filter estimation - Second order polynomial
figure(3);
subplot(3,2,1);
plot(t,real_pos,'--',t,X_est(1,:));
title("Comparaison between real Vs. estimated position [rad]");
xlabel("Time [s]");
ylabel("Position [rad]");

subplot(3,2,2);
err_pos = real_pos-X_est(1,:);
plot(t,err_pos,t,pos_bound,'--',t,-pos_bound,'--');
title("Position estimation error [rad]");
xlabel("Time [s]");
ylabel("Position [rad]");

subplot(3,2,3);
plot(t,real_vel,'--',t,X_est(2,:));
title("Comparaison between real Vs. estimated velocity [rad/s]");
xlabel("Time [s]");
ylabel("Angular velocity [rad/s]");

subplot(3,2,4);
err_vel = real_vel-X_est(2,:);
plot(t,err_vel,t,vel_bound,'--',t,-vel_bound,'--');
title("Velocity estimation error [rad/s]");
xlabel("Time [s]");
ylabel("Angular velocity [rad/s]");

subplot(3,2,5);
plot(t,real_acc,'--',t,X_est(3,:));
title("Comparaison between real Vs. estimated acceleration [rad/s^2]");
xlabel("Time [s]");
ylabel("Angular acceleration [rad/s^2]");

subplot(3,2,6);
err_vel = real_acc-X_est(3,:);
plot(t,err_vel,t,acc_bound,'--',t,-acc_bound,'--');
title("Acceleration estimation error [rad/s^2]");
xlabel("Time [s]");
ylabel("Angular acceleration [rad/s^2]");

