%% Paramètres du système

T = 10;
dt = 0.01;
t = 0:dt:Tm;

Opot = 0.02;
Ogyro = 0.02;


Jz = 0.0576;
L = 0.65;
d = 0.48;
m = 0.22;
Fr = 0.1;
g = 9.81;

A = zeros(size(t));
V = zeros(size(t));
X = zeros(size(t));

Gyro = zeros(size(t));
Pot = zeros(size(t));

A(1) = 0;
V(1) = 0;
X(1) = pi/4;

%% Modélisation du système

Force = ones(size(t))*1.5;

for i = 2:1:size(t,2)

    A(i) = (1/Jz) * ( L * Force(i-1) - d * m * g * sin(X(i-1)) - Fr * V(i-1));
    V(i) = V(i-1) + A(i) * dt;
    %V(i) = max(min(V(i), 5), -5);
    X(i) = X(i-1) + V(i) * dt;

    if X(i) <= X(1)
        A(i) = 0;
        V(i) = 0;
        X(i) = pi/4;
    elseif X(i) >= pi
        A(i) = 0;
        V(i) = 0;
        X(i) = pi;
    end

    Pot(i) = X(i) + randn(1) .* Opot;
    Gyro(i) = V(i) + randn(1) .* Ogyro;

end

%plot(t, A, 'r', t, V, 'b', t, X, 'g');

%plot(t, X, 'r', t, Pot, 'b', t, V, "m", t, Gyro, 'c');

%% First-order Polynomial Kalman Filter with Process Noise

% Vecteurs d'estimation
V_est = zeros(size(t));
X_est = zeros(size(t));
Verror_est = zeros(size(t));
Xerror_est = zeros(size(t));

% Vecteurs d'observations
Y = zeros(2, size(t,2));
Y(1,:) = Pot;
Y(2,:) = Gyro;

% Matrice du filtre

I = eye(2);
H = [1 0; 0 1]; 
R = [Opot^2 0; 0 Ogyro^2];
G = [(L*dt^2)/(2*Jz) ; (L*dt)/Jz];
U = Force(1);
gamma = 0.6;

% Paramètres initiaux
Xk = zeros(2,size(t,2));
Xk(:,1) = [pi/4 0];

Pk_k1 = [10^1 0 ; 0 10^1];

% Calculs du filtre
for i = 2:1:size(t,2)
    
    A = (-d*m*g/Jz)*cos(Xk(1,i-1));

    F = [0 1 ; A 0];
    phi_d = I + F * dt;

    Q = [ dt * (1 + (dt^2/3))   ,  (dt^2/2) * (A + 1) ;
         (dt^2/2) * (A + 1)  ,  (dt^3/3) * A^2 + dt  ];

    Q = Q.*gamma;

    K = Pk_k1 * H' / ( H * Pk_k1 * H' + R );

    Pk_k = ( I - K * H ) * Pk_k1;
    Pk_k1 = phi_d * Pk_k * phi_d' + Q;

    Xk(:,i) = Xk(:,i-1) + K * ( Y(:,i) - H * Xk(:,i-1));

    X_est(i) = Xk(1,i);
    V_est(i) = Xk(2,i);
    Xerror_est(i) = sqrt(Pk_k1(1,1));
    Verror_est(i) = sqrt(Pk_k1(2,2));

    Xk(:,i) = phi_d * Xk(:,i) + G * U;

end

%% Test d'affichage


%plot(t, X, 'r', t, Pot, 'b', t, V, "m", t, Gyro, 'c');


%% Affichage des résultats sans acceleration

subplot(2,2,1)
plot(t, X_est, 'r', t, X, 'b')
ylim([pi/4 pi]);
title("Comparison between: position estimate vs. truth, [rad]");
ylabel("Arm's position [rad]");
xlabel("Time [s]");
legend("position estimate", "measure position");

subplot(2,2,3)
plot(t, V_est, 'r', t, V, 'b')
ylim([-2 2]);
title("Comparison between: velocity estimate vs. truth, [rad/s]");
ylabel("Arm's velocity [rad/s]");
xlabel("Time [s]");
legend("velocity estimate", "true velocity");

subplot(2,2,2)
plot(t, X-X_est, 'b', t, Xerror_est, 'r--', t, -Xerror_est, 'r--')
ylim([-0.25 0.25]);
title("Analysis of the position estimation error");
ylabel("Position error [rad]");
xlabel("Time [s]");

subplot(2,2,4) 
plot(t, V-V_est, 'b', t, Verror_est, 'r--', t, -Verror_est, 'r--')
ylim([-0.25 0.25]);
title("Analysis of the velocity estimation error");
ylabel("Velocity error [rad/s]");
xlabel("Time [s]");